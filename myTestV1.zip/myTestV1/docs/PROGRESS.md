# PROGRESS（Claude Code 唯一可写的 docs 文件）

## 使用规则
- 状态：`TODO` → `DOING` → `DONE` / `BLOCKED`。
- `DOING` 时填开始时间；`DONE` 时填完成时间与冒烟结果摘要（如 `T09: 14 passed`）。
- `BLOCKED` 时在备注写：失败命令、错误摘要、已尝试的修正（最多 3 轮）。
- 只追加，不删除历史备注。

## 任务表

| ID | 名称 | 前置 | 状态 | 开始 | 完成 | 冒烟结果 / 备注 |
|---|---|---|---|---|---|---|
| T00 | 解决方案骨架与环境检查 | — | TODO | | | |
| T01 | 配置文件与加载器 | T00 | TODO | | | |
| T02 | IR 模型、Schema、NDJSON | T00 | TODO | | | |
| T03 | SQLite 存储层与规范化导出 | T02 | TODO | | | |
| T04 | 夹具：C# 源码与 rsp | T00 | TODO | | | |
| T05 | 夹具：资源与 CP932 文件 | T04 | TODO | | | |
| T06 | rsp 发现、解析、预检、编码 | T01 T05 | TODO | | | |
| T07 | Compilation 构建 | T06 | TODO | | | |
| T08 | 符号、impl、稳定 ID、变更标记 | T02 T07 | TODO | | | |
| T09 | 方法体与 Value 折叠 | T08 | TODO | | | |
| T10 | 条件、CFG 可达性、lambda | T09 | TODO | | | |
| T11 | 构建管线与 Core 解析服务 | T03 T10 | TODO | | | |
| T12 | 锚点 + screens/enumerations/navigation | T11 | TODO | | | |
| T13 | 资源解析器 | T05 T11 | TODO | | | |
| T14 | ui-bindings 适配器 | T12 T13 | TODO | | | |
| T15 | tcp 适配器 | T12 | TODO | | | |
| T16 | keyseq 与 di 适配器 | T12 | TODO | | | |
| T17 | 边界类与入口适配器 | T14 T15 T16 | TODO | | | |
| T18 | 画面操作图与断链 | T17 | TODO | | | |
| T19 | 路径搜索 | T18 | TODO | | | |
| T20 | CLI 全命令、查询、确定性 | T19 | TODO | | | |
| T21 | Python MCP 服务 | T20 | TODO | | | |
| T22 | Copilot 部署文件 | T21 | TODO | | | |
| T23 | 本机验收脚本 | T20 | TODO | | | |

## 待本机确认

由 Claude Code 在实现中发现的、需要在真实源码上确认的假设，逐行追加：

| # | 内容 | 相关配置 / 代码 | 登记任务 |
|---|---|---|---|
| Q-01 | Unity 2022.3.68f1 生成的 rsp 实际位置与格式（03 §2） | `RspParser`、`profiles.json` | 设计时 |
| Q-02 | Android Player 编译 rsp 的生成方式（需 Player 构建）与其 define | `profiles.json` `selectPlatform` | 设计时 |
| Q-03 | 员工面 TcpPresenter 是否同样按 `Common.*` 显示类事件远程显示画面 | `tcp.displayEventIdsVerifiedTerminals` | 设计时 |
| Q-04 | 员工面字符串表的集合名与检索顺序 | `resources.stringTableSearchOrder.employee` | 设计时 |
| Q-05 | 模型队列 `AddQueue` 与 `ElementRequest` 的实际类型与文件位置 | `queue.*` | 设计时 |
| Q-06 | `ApiRequest` 的文件位置与构造形参名 | `api.requestType`、`api.apiKeyParamNames` | 设计时 |
| Q-07 | SQLite 执行 API 的实际类型/方法名 | `sql.*` | 设计时 |

## 会话日志

（每次会话结束时追加一行：日期、完成的任务、BLOCKED 的任务、新增的待确认项）
